/*****************************************************************************************************************
 * Author: Ajantha Dhanasekaran
 * Date: 07-Sept-2020
 * Purpose: Gateway client to communicate charger commands with Iot Hub
 * Change History:
 * Name                         Date                    Change description
 * Ajantha Dhanasekaran         07-Sept-2020              Initial version
 * Ajantha Dhanasekaran         16-Sept-2020              Enabled logging
 * Ajantha Dhanasekaran         23-Sept-2020              Enabled additional logging; Modified _chargerClients to be 
                                                                    thread-safe
 * ****************************************************************************************************************/


#region license

/*
Cognizant EV Charging Protocol Gateway 1.0
© 2020 Cognizant. All rights reserved.
"Cognizant EV Charging Protocol Gateway 1.0" by Cognizant  is licensed under Apache License Version 2.0


Copyright 2020 Cognizant


Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at


    http://www.apache.org/licenses/LICENSE-2.0


Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#endregion

using System;
using System.Text;
using Newtonsoft.Json;
using ProtocolGateway.Models;
using System.Threading.Tasks;
using Microsoft.Azure.Devices;
using System.Collections.Generic;
using ProtocolGateway.Models.OCPP;
using System.Collections.Concurrent;
using System.Text.RegularExpressions;
using Microsoft.Azure.Devices.Client;
using Microsoft.Azure.Devices.Shared;
using Microsoft.Extensions.Configuration;

namespace ProtocolGateway
{
    public class GatewayClient : IGatewayClient
    {
        private static RegistryManager _registryManager = null;
        private static ConcurrentDictionary<string, DeviceClient> _chargerClients = new ConcurrentDictionary<string, DeviceClient>();
        private static Dictionary<string, TwinRequestInfo> _chargerTwinRequests = new Dictionary<string, TwinRequestInfo>();
        private static string _hostname = null;
        private static Func<string, object, Task> _sendToCharger = null;
        private readonly IConfiguration _configuration;
        private readonly int _bootInterval;
        private static Logger _logger;

        public GatewayClient(IConfiguration configuration, string connectionString)
        {
            if (Regex.IsMatch(connectionString, @"^HostName=.*;SharedAccessKeyName=.*;SharedAccessKey=.*$"))
            {
                _hostname = connectionString.Split(";")[0].Split("=")[1];
                _registryManager = RegistryManager.CreateFromConnectionString(connectionString);
            }
            _configuration = configuration;
            _logger = new Logger();
            String interval = string.IsNullOrEmpty(_configuration["OCPPBootInterval"]) ? "120" : _configuration["OCPPBootInterval"];
            _bootInterval = Convert.ToInt32(interval);


        }

        /// <summary>
        /// This method sets the callback method that has to be invoked to send the payload to the charger
        /// </summary>
        /// <param name="action">send method</param>
        public void SetSendToChargepointMethod(Func<string, object, Task> action)
        {
            _logger.LogInformation("Setting SendToCharger method");
            _sendToCharger = action;
        }

        /// <summary>
        /// This method gets all the chargerIds registered in the IoT Hub.
        /// </summary>
        /// <returns></returns>
        public async Task<List<string>> GetAllChargersAsync()
        {
            _logger.LogInformation("Getting all chargerIDs from IoTHub");

            List<string> chargerIds = new List<string>();

            if (_registryManager == null)
                return chargerIds;

            var query = _registryManager.CreateQuery(Constants.GetAllDeviceIdsQuery);

            while (query.HasMoreResults)
            {
                var data = await query.GetNextAsJsonAsync();

                foreach (var chargerData in data)
                {
                    var charger = JsonConvert.DeserializeObject<ChargerDevice>(chargerData);
                    chargerIds.Add(charger.DeviceId);
                }

            }

            _logger.LogInformation("Got all chargerIDs from IoTHub");

            return chargerIds;

        }

        /// <summary>
        /// This method closes and removes all the charger device client connections 
        /// </summary>
        /// <returns></returns>
        public async Task CloseAsync()
        {

            _logger.LogInformation("Closing gateway client");

            foreach (var client in _chargerClients)
                await client.Value.CloseAsync();

            if (_chargerClients.Count != 0)
                _chargerClients.Clear();

            if (_chargerTwinRequests.Count != 0)
                _chargerTwinRequests.Clear();
        }

        /// <summary>
        /// This method removes the inactive chargerpoint from the dictionary
        /// </summary>
        /// <param name="chargepointName">Id of the charger</param>
        /// <returns></returns>
        public async Task RemoveChargepointAsync(string chargepointName)
        {

            _logger.LogInformation($"Gateway Client : Removing chargepoint {chargepointName}");

            if (_chargerClients.ContainsKey(chargepointName))
            {
                _chargerClients.TryRemove(chargepointName, out var client);
                await client.CloseAsync();
            }

            if (_chargerTwinRequests.ContainsKey(chargepointName))
                _chargerTwinRequests.Remove(chargepointName);

        }

        /// <summary>
        /// This method verifies the BootNotification request and sends back appropriate response
        /// </summary>
        /// <param name="request">request payload</param>
        /// <param name="chargepointName">charger Id</param>
        /// <returns></returns>
        public async Task<ResponsePayload> SendBootNotificationAsync(RequestPayload request, string chargepointName)
        {
            _logger.LogInformation($"Gateway Client : Sending BootNotification for {chargepointName}");

            BootNotificationResponse bootNotificationResponse = null;
            RequestPayload requestPayload = new RequestPayload(request);
            ResponsePayload responsePayload = null;

            var deviceExists = await CreateDeviceClient(chargepointName);

            if (!deviceExists)
            {
                bootNotificationResponse = new BootNotificationResponse(Constants.BootRejected, _bootInterval);
                responsePayload = new ResponsePayload(requestPayload.UniqueId, bootNotificationResponse);
                return responsePayload;
            }

            bootNotificationResponse = new BootNotificationResponse(Constants.BootAccepted, _bootInterval);
            responsePayload = new ResponsePayload(requestPayload.UniqueId, bootNotificationResponse);
            return responsePayload;
        }

        /// <summary>
        /// This method updates Authorize, StartTransaction and StopTransaction as ReportedProperties for the given charger */
        /// </summary>
        /// <param name="request">request payload</param>
        /// <param name="chargepointName">charger Id</param>
        /// <returns></returns>
        public async Task SendTransactionMessageAsync(RequestPayload request, string chargepointName)
        {

            _logger.LogInformation($"Gateway Client : Updating {request.Action} for chargepoint {chargepointName}");

            try
            {

                if (!_chargerClients.ContainsKey(chargepointName))
                {
                    if (!await CreateDeviceClient(chargepointName))
                        return;
                }

                RequestPayload requestPayload = (RequestPayload)request;
                requestPayload.Payload.Add(Constants.StationChargerTag, chargepointName);
                TwinRequestInfo twinRequestInfo = new TwinRequestInfo(requestPayload.UniqueId, requestPayload.Action);

                if (_chargerTwinRequests.ContainsKey(chargepointName))
                    _chargerTwinRequests[chargepointName] = twinRequestInfo;
                else
                    _chargerTwinRequests.Add(chargepointName, twinRequestInfo);

                var client = _chargerClients[chargepointName];
                TwinCollection twins = new TwinCollection();
                twins[requestPayload.Action] = requestPayload.Payload;
                await client.UpdateReportedPropertiesAsync(twins);

                _logger.LogInformation($"Gateway Client : Updated {request.Action} for chargepoint {chargepointName}");
            }
            catch (Exception e)
            {
                _logger.LogError(chargepointName, "Gateway client : SendTransactionMessageAsync", e);
            }
        }

        /// <summary>
        /// This method sends the telemetries such as Heartbeat,StatusNotification and MeterValues to the IoTHub
        /// </summary>
        /// <param name="request">request payload</param>
        /// <param name="chargepointName">charger Id</param>
        /// <returns></returns>
        public async Task SendTelemetryAsync(object request, string chargepointName)
        {

            _logger.LogInformation($"Gateway Client : Sending telemetry for chargepoint {chargepointName}");

            try
            {
                if (!_chargerClients.ContainsKey(chargepointName))
                {
                    if (!await CreateDeviceClient(chargepointName))
                        return;
                }

                var client = _chargerClients[chargepointName];
                var serializedPayload = JsonConvert.SerializeObject(request);
                Microsoft.Azure.Devices.Client.Message message = new Microsoft.Azure.Devices.Client.Message(Encoding.UTF8.GetBytes(serializedPayload));

                await client.SendEventAsync(message);

                _logger.LogInformation($"Gateway Client : Sent telemetry for chargepoint {chargepointName}");
            }
            catch (Exception e)
            {
                _logger.LogError(chargepointName, "Gateway Client : SendTelemetryAsync ", e);
            }

        }

        //Helper methods

        /// <summary>
        /// This method listens to Authorize and other transaction message response (desired properties) from the IoTHub
        /// </summary>
        /// <param name="twins">twin properties</param>
        /// <param name="userContext">chargerpointname</param>
        /// <returns></returns>
        private async Task OnTransactionMessageResponse(TwinCollection twins, object userContext)
        {
            var chargepointName = userContext.ToString();
            ResponsePayload responsePayload = null;

            _logger.LogInformation($"Gateway Client : Received property update for {chargepointName}.");

            try
            {

                if (_chargerTwinRequests.ContainsKey(chargepointName))
                {
                    var twinRequestInfo = _chargerTwinRequests[chargepointName];
                    if (twins.Contains(twinRequestInfo.Action))
                    {
                        object payload = twins[twinRequestInfo.Action];

                        responsePayload = new ResponsePayload(twinRequestInfo.UniqueId, payload);
                        _chargerTwinRequests.Remove(chargepointName);
                        await _sendToCharger(chargepointName, responsePayload.WrappedPayload);

                        _logger.LogInformation($"Gateway Client : Sending updated response for {chargepointName}.");
                    }
                    else
                        _logger.LogTrace($"Gateway Client : No action found in twins but Desired update received for {chargepointName}. Twins : {JsonConvert.SerializeObject(twins)}");

                }
                else
                    _logger.LogTrace($"Gateway Client : No record in dictionary but Desired update received for {chargepointName}. Twins : {JsonConvert.SerializeObject(twins)}");


            }
            catch (Exception e)
            {
                _logger.LogError(chargepointName, "Gateway Client : OnTransactionMessageAsync ", e);
            }


        }

        /// <summary>
        /// This method creates the device client for a chargepoint
        /// </summary>
        /// <param name="chargepointName"></param>
        /// <returns></returns>
        private async Task<bool> CreateDeviceClient(string chargepointName)
        {

            _logger.LogInformation($"Gateway Client : Creating device client for {chargepointName}.");

            if (_registryManager == null)
                return false;

            var device = await _registryManager.GetDeviceAsync(chargepointName);

            if (device == null || _hostname == null)
                return false;

            var key = Microsoft.Azure.Devices.Client.AuthenticationMethodFactory.CreateAuthenticationWithRegistrySymmetricKey(chargepointName, device.Authentication.SymmetricKey.PrimaryKey);
            var client = DeviceClient.Create(_hostname, key);
            await client.SetDesiredPropertyUpdateCallbackAsync(OnTransactionMessageResponse, chargepointName);

            if (!_chargerClients.ContainsKey(chargepointName))
                _chargerClients.TryAdd(chargepointName, client);

            _logger.LogInformation($"Gateway Client : Creating device client for {chargepointName}.");
            return true;


        }

    }
}