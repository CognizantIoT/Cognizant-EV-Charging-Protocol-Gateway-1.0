﻿/*****************************************************************************************************************
 * Author: Ajantha Dhanasekaran
 * Date: 07-Sept-2020
 * Purpose: Startup of EV central system 
 * Change History:
 * Name                         Date                    Change description
 * Ajantha Dhanasekaran         07-Sept-2020              Initial version
 * Ajantha Dhanasekaran         15-Sept-2020              Enabled HSTS,secure and HttpOnlycookies,HttpsRedirection;
                                                                Modified CORS policy
 * Ajantha Dhanasekaran         16-Sept-2020               Removed CORS, DevelopmentExceptionPage middleware; Added custom middleware 
                                                                to add response header 
 * Ajantha Dhanasekaran         23-Sept-2020              Added HSTS response header    
 * Ajantha Dhanasekaran         28-Sept-2020              Added HSTS service                                                             
 * ****************************************************************************************************************/

#region license

/*
Cognizant EV Charging Protocol Gateway 1.0
© 2020 Cognizant. All rights reserved.
"Cognizant EV Charging Protocol Gateway 1.0" by Cognizant  is licensed under Apache License Version 2.0


Copyright 2020 Cognizant


Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at


    http://www.apache.org/licenses/LICENSE-2.0


Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#endregion

using System;
using ProtocolGateway;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;


namespace ChargePointOperator
{
    public class Startup
    {
        private readonly IConfiguration _configuration;

        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {

            services.Configure<CookiePolicyOptions>(o =>
            {
                o.Secure = CookieSecurePolicy.Always;
                o.HttpOnly = Microsoft.AspNetCore.CookiePolicy.HttpOnlyPolicy.Always;

            });

            services.AddHsts(options =>
            {
                options.Preload = true;
                options.IncludeSubDomains = true;
                options.MaxAge = TimeSpan.FromDays(365);
            });
            string connectionString = _configuration["IoTHubString"];

            //Injecting the Protocol gateway client
            services.AddSingleton<IGatewayClient>(new GatewayClient(_configuration, connectionString));

        }


        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory logger, IServiceScopeFactory serviceScope)//
        {

            app.UseHsts();
            app.UseHttpsRedirection();
            app.UseCookiePolicy();

            //Defining websocketoptions for ping/pong frames
            var webSocketOptions = new WebSocketOptions
            {
                KeepAliveInterval = TimeSpan.FromSeconds(1)

            };

            app.Use(async (context, next) =>
            {
                context.Request.Headers.TryGetValue("Origin", out var origin);
                context.Response.Headers.Append("Access-Control-Allow-Origin", origin);
                context.Response.Headers.Append("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
                await next();
            });

            //Adding Websockets
            app.UseWebSockets(webSocketOptions);

            //Adding custom websocketmiddleware to the pipeline
            app.UseMiddleware<WebsocketMiddleware>();

            app.Run(async (context) =>
            {
                if (context.Request.Path.Value.Contains("favicon.") || context.Request.Path.Value == "/")
                    await context.Response.WriteAsync("CPO running");
                else
                    await context.Response.WriteAsync("Invalid Request");
            });
        }
    }
}
