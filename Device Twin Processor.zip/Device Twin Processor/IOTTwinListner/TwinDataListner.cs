/*****************************************************************************************************************
 * Author: Pramod Gawande
 * Date: 24-Aug-2020
 * Purpose: function to handle the device authorize, start transaction and stop transaction requests
 * Change History:
 * Name                         Date                    Change description
 * Pramod Gawande               24-Aug-2020              Initial version
 * Pramod Gawande               28-Aug-2020              Added Authorization Functionality
 * ****************************************************************************************************************/
/*
Cognizant EV Charging Protocol Gateway 1.0

� 2020 Cognizant. All rights reserved.

"Cognizant EV Charging Protocol Gateway 1.0" by Cognizant  is licensed under Apache License Version 2.0

Copyright 2020 Cognizant

Licensed under the Apache License, Version 2.0 (the "License");

you may not use this file except in compliance with the License.

You may obtain a copy of the License at
    http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software

distributed under the License is distributed on an "AS IS" BASIS,

WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the License for the specific language governing permissions and

limitations under the License.
*/

using Microsoft.Azure.Devices.Shared;
using Microsoft.Azure.EventHubs;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOTTwinListner
{
    public static class TwinDataListner
    {
        /// <summary>
        /// This is event hub trigger function, it gets triggers when event hub received autorize/ start transaction/stop transaction event.
        /// This function reads reported properties set by charger aplication and set desired properties as output
        /// </summary>
        /// <param name="events"></param>
        /// <param name="log"></param>
        /// <returns></returns>
        [FunctionName("TwinDataProcessor")]
        public static async Task Run([EventHubTrigger("samples-workitems", Connection = "EventHubConnectionString")] EventData[] events, ILogger log)
        {
            var exceptions = new List<Exception>();
            EventProcessor eventProcessor = new EventProcessor();

            foreach (EventData eventData in events)
            {
                try
                {
                    // collect devide id for further operations
                    string deviceId = eventData.SystemProperties["iothub-connection-device-id"].ToString();
                    log.LogInformation("Processing For Charger Id:" + deviceId);
                    var messageBody = Encoding.ASCII.GetString(eventData.Body.Array,
                        eventData.Body.Offset,
                        eventData.Body.Count);

                    log.LogInformation(messageBody);
                    Twin tw = JsonConvert.DeserializeObject<Twin>(messageBody);

                    //start transaction event
                    if (tw.Properties.Reported.Contains(Constants.StartTransaction) == true)
                    {
                        StartTransaction startTransaction = JsonConvert.DeserializeObject<StartTransaction>(tw.Properties.Reported[Constants.StartTransaction].ToString());

                        // Call platform start transaction API and get the output
                        var output = eventProcessor.StartChargeTransaction(startTransaction);

                        if (output != null)
                        {
                            // set desired properties as return response
                            await IOTCommunicator.UpdateStartDesiredProperties(output, deviceId);
                        }
                    }
                    // stop transaction event
                    else if (tw.Properties.Reported.Contains(Constants.StopTransaction) == true)
                    {
                        StopTransaction stopTransaction = JsonConvert.DeserializeObject<StopTransaction>(tw.Properties.Reported[Constants.StopTransaction].ToString());
                        // Call platform stop transaction API and get the output
                        var output = eventProcessor.StopChargeTransaction(stopTransaction);
                        if (output != null)
                        {
                            // set desired properties as return response
                            await IOTCommunicator.UpdateStopDesiredProperties(output, deviceId);
                        }
                    }
                    // charger authorize event
                    else if (tw.Properties.Reported.Contains(Constants.Authorize) == true)
                    {
                        log.LogInformation($"Device Id : {deviceId}");
                        AuthToken authToken = JsonConvert.DeserializeObject<AuthToken>(tw.Properties.Reported[Constants.Authorize].ToString());
                        // Call platform Authorize API and get the output
                        var output = eventProcessor.AuthorizeCharger(authToken);
                        if (output != null)
                        {
                            // set desired properties as return response
                            await IOTCommunicator.UpdateAuthDesiredProperties(output, deviceId);
                        }
                    }

                    log.LogInformation($"C# Event Hub trigger function processed a message: {messageBody}");
                    await Task.Yield();
                }
                catch (Exception e)
                {
                    Logger.ErrorLogger(e, log);
                    exceptions.Add(e);
                }
            }

            if (exceptions.Count > 1)
                throw new AggregateException(exceptions);

            if (exceptions.Count == 1)
                throw exceptions.Single();
        }
    }
}