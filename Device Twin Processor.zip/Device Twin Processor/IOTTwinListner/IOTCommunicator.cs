﻿/*****************************************************************************************************************
 * Author: Pramod Gawande
 * Date: 24-Aug-2020
 * Purpose: function to set the IOT hub desired properties as event output
 * Change History:
 * Name                         Date                    Change description
 * Pramod Gawande               24-Aug-2020              Initial version
 * Pramod Gawande               28-Aug-2020              Added Authorization Functionality
 * ****************************************************************************************************************/
/*
Cognizant EV Charging Protocol Gateway 1.0

© 2020 Cognizant. All rights reserved.

"Cognizant EV Charging Protocol Gateway 1.0" by Cognizant  is licensed under Apache License Version 2.0

Copyright 2020 Cognizant

Licensed under the Apache License, Version 2.0 (the "License");

you may not use this file except in compliance with the License.

You may obtain a copy of the License at
    http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software

distributed under the License is distributed on an "AS IS" BASIS,

WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the License for the specific language governing permissions and

limitations under the License.
*/

using Microsoft.Azure.Devices;
using System;
using System.Threading.Tasks;

namespace IOTTwinListner
{
    public class IOTCommunicator
    {
        /// <summary>
        /// Update desired properties for start transaction response
        /// </summary>
        /// <param name="input"></param>
        /// <param name="deviceId"></param>
        /// <returns></returns>
        public static async Task UpdateStartDesiredProperties(StartTransactionOutPut input, string deviceId)
        {
            using (var registryManager = GetRegistryManager())
            {
                var twin = await registryManager.GetTwinAsync(deviceId).ConfigureAwait(false);

                var patch = @"{properties:{desired:{StartTransaction:{idTagInfo: {expiryDate: " + "\"" + input.idTagInfo.expiryDate + "\",parentIdTag: \"" + input.idTagInfo.parentIdTag +
                    "\",status: \"" + input.idTagInfo.status + "\"},transactionId: " + input.transactionId + "}}}}";

                await registryManager.UpdateTwinAsync(twin.DeviceId, patch, twin.ETag).ConfigureAwait(false);
            }
        }

        /// <summary>
        /// Update desired properties for stop transaction response
        /// </summary>
        /// <param name="input"></param>
        /// <param name="deviceId"></param>
        /// <returns></returns>
        public static async Task UpdateStopDesiredProperties(StopTransactionOutPut input, string deviceId)
        {
            using (var registryManager = GetRegistryManager())
            {

                var twin = await registryManager.GetTwinAsync(deviceId).ConfigureAwait(false);

                var patch = @"{properties:{desired:{StopTransaction:{idTagInfo: {expiryDate: " + "\"" + input.IdTagInfo.expiryDate + "\",parentIdTag: \"" + input.IdTagInfo.parentIdTag + "\",status: \"" +
                    input.IdTagInfo.status + "\"}}}}}";

                await registryManager.UpdateTwinAsync(twin.DeviceId, patch, twin.ETag).ConfigureAwait(false);
            }
        }

        /// <summary>
        /// Update desired properties for charger authorize response
        /// </summary>
        /// <param name="input"></param>
        /// <param name="deviceId"></param>
        /// <returns></returns>
        public static async Task UpdateAuthDesiredProperties(AuthorizeOutPut input, string deviceId)
        {
            using (var registryManager = GetRegistryManager())
            {
                var twin = await registryManager.GetTwinAsync(deviceId).ConfigureAwait(false);

                var patch = @"{properties:{desired:{Authorize:{idTagInfo: {expiryDate: " + "\"" + input.idTagInfo.expiryDate + "\",parentIdTag: \"" + input.idTagInfo.parentIdTag + "\",status: \"" +
                    input.idTagInfo.status + "\"}}}}}";

                await registryManager.UpdateTwinAsync(twin.DeviceId, patch, twin.ETag).ConfigureAwait(false);
            }
        }

        /// <summary>
        /// Create registry manager object to communicate with IOT hub
        /// </summary>
        /// <returns></returns>
        private static RegistryManager GetRegistryManager()
        {
            string IOTConnectionString = Environment.GetEnvironmentVariable("IOTHubConnectionString");
            var registryManager = RegistryManager.CreateFromConnectionString(IOTConnectionString);

            return registryManager;
        }
    }
}